class RunContext {
  static bool isFromWM = false; // 是否来自WorkManager回调
  static bool isBackground = false;
}
